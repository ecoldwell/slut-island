<header id="main-header">
  <h1>
    <a href="/">SLUT ISLAND</a>
  </h1>

  <?php wp_nav_menu(
    array(
      'theme_location'  => 'primary',
      'container_class' => 'main-nav-menu',
      'menu_class'      => 'navbar-nav',
      'fallback_cb'     => '',
      'menu_id'         => 'main-menu'
    )
  ); ?>

</header>
