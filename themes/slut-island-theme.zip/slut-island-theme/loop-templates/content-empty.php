<?php
/**
 * Content empty partial template.
 *
 * @package understrap
 */

the_content();
